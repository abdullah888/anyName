//
//  Project_appApp.swift
//  Project app
//
//  Created by abdullah FH on 15/07/1446 AH.
//

import SwiftUI

@main
struct Project_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
